package com.klef.jfsd.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
