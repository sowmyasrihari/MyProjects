package com.klef.jfsd.springboot.service;

import com.klef.jfsd.springboot.model.ProjectReview;

public interface ProjectReviewService {
public ProjectReview addprojectreview(ProjectReview projectReview);
}
